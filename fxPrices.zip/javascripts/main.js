(function($) {
    'use strict';

    var symbols = ['AUD', 'CAD', 'CHF', 'EUR', 'GBP', 'JPY', 'NOK', 'NZD', 'SEK', 'USD'],
        fxRatesApiUrl = 'http://api.fixer.io/latest?callback=?',
        slickGrid,
        CURRENCY_SYMBOL_COLUMN_ID = 'currencySymbol',
        currencySymbolColumn = (function() {
            var column = {};
            column['id'] = CURRENCY_SYMBOL_COLUMN_ID;
            column['name'] = '';
            column['field'] = CURRENCY_SYMBOL_COLUMN_ID;

            return column;
        })(),
        columns = [currencySymbolColumn].concat(_.map(symbols, function(symbol) {
            var column = {};
            column['id'] = symbol;
            column['name'] = symbol;
            column['field'] = symbol;

            return column;
        })),

        options = {
            enableCellNavigation: true,
            enableColumnReorder: false
        };

    function getRatesMatrix() {

        var concatenatedSymbols = symbols.join(','),
            promises = _.map(symbols, function(symbol) {
                return getSymbolsByBase(symbol, concatenatedSymbols);
            });

        return Q.allSettled(promises)
            .then(function onFulfilled(results) {
                var ratesMatrix = {};

                _.forEach(results, function(result, index) {
                    // augment the result for the current symbol against itself (i.e. USD <> USD = 1)
                    var currentSymbol = symbols[index],
                        symbolRates = {};

                    if (result.state === 'fulfilled') {
                        symbolRates = result.value.rates;
                        symbolRates[currentSymbol] = 1;
                    } else {
                        _.forEach(symbols, function(symbol) {
                            symbolRates[symbol] = -1;   // -1 indicates data was unavailable
                        });
                    }

                    ratesMatrix[currentSymbol] = symbolRates;
                });

                return Q(ratesMatrix);
            });
    }

    function getSymbolsByBase(base, symbols) {
        var deferred = Q.defer();

        $.ajax({
                data: {
                    base: base,
                    symbols: symbols
                },
                dataType: 'json',
                method: 'GET',
                url: fxRatesApiUrl
            })
            .done(function onDone(response) {
                deferred.resolve(response);
            })
            .fail(function onFail(error) {
                deferred.reject(error);
            });

        return deferred.promise;
    }

    function matrixToSlickGridData(matrix) {
        var data = [];

        _.forEach(matrix, function(value, key) {
            value[CURRENCY_SYMBOL_COLUMN_ID] = key;
            data.push(value);
        });

        return data;
    }

    function ratesRefresher() {

        getRatesMatrix()
            .then(function onFulfilled(matrix) {
                var data = matrixToSlickGridData(matrix);
                slickGrid.setData(data);
                slickGrid.render();
            })
            .fin(function() {
                setTimeout(ratesRefresher, 500);    // refresh every half a second
            });

    }

    // when the DOM is ready
    $(function () {

        // initialise the grid with empty data
        slickGrid = new Slick.Grid('#fxGrid', [], columns, options);

        // we could prefetch this data before the DOM is ready but, as it's super fast to get, there is no need right now
        ratesRefresher();
    });
})(jQuery);